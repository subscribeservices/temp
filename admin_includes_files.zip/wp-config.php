<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'wordpress' );

/** MySQL database password */
define( 'DB_PASSWORD', 'Pa55w04d123$' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */

define('AUTH_KEY',         'HdMaJ&R,u }W.#K]3k-t3{~zVh1[+S%~&&N~K:AL~v&a([B`-W]EXqy~k-YeAh?{');
define('SECURE_AUTH_KEY',  'G0D``=d~jJ7+OBZI[y<<}TdWXK>#0_DoINQXqA&0Dc#=icuBdk|BD+ oYtbh7Y%|');
define('LOGGED_IN_KEY',    '{aTw2Gr0%U{:m~|rg]q]FAgRJ4Up3EmTUxWn[tu75f3AwgIBx2<JY1R4;4UN+~F[');
define('NONCE_KEY',        '<<B736)Z?_DJel!|sc%O8:%*xF##Y-t(&V%Q<-)lhT%i|lMGTA|=I$LHOn+&0!1t');
define('AUTH_SALT',        'atxma@Ay0LdPX%L#3X33d+nHdCKgu6px uFNFu(v_y~M,@c{%ZD$J;Qbe~%ygs6O');
define('SECURE_AUTH_SALT', 's Z[huAgm{2a/%<W.mjs%]XAHL*$Yz?-8&6aV[/{9-)_+sakU*ATv)|L};j6-AC+');
define('LOGGED_IN_SALT',   'eg-77bP:B`R(j(6spx7@Ah[&sb9g9}8^x6Fi@ms;([xoG8$DD{FO6w9xLXbxn-+ ');
define('NONCE_SALT',       ' v&.EC]d$DB~93w@k|:?%6@|MD_CcLB{g nkPQef#C9v6yD{gKvxSYc-!DXx+u1$');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
        define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );

define('FS_METHOD', 'direct');
